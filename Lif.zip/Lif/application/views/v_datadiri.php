<!DOCTYPE html>
<html>
<head>
    <title>Data Diri</title>
</head>
<body>

 <table border="1px solid black">
<tr>
 <th>NAMA DATA DIRI</th>
<th>EMAIL</th>
<th>AGAMA</th>
<th>ALAMAT</th>
<th>TANGGAL LAHIR</th>
<th colspan="2">AKSI</th>

</tr>

<?php foreach ($data_diri as $db_alif) : ?>

<tr>
 <td><?php echo $db_alif['nama']; ?></td>
<td><?php echo $db_alif['email']; ?></td>
<td><?php echo $db_alif['agama']; ?></td>
<td><?php echo $db_alif['alamat']; ?></td>
<td><?php echo $db_alif['tgl_lahir']; ?></td>
<td><div class="btn btn-danger"><i class="fa fa-trans"></i></div></td>
</tr>


<?php endforeach;  ?>

</table>
</body>
</html>