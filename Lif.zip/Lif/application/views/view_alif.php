<!DOCTYPE html>
<html>
<head>
    <title>View Alif</title>
</head>
<body>

 <h1>View Alif Pada Codeigniter</h1>
 <hr>
<p>Belajar Untuk Melupakan Dia</p>

</body>
</html>