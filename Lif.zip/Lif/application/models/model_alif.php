<?php 

class model_alif extends CI_Model {
   public function get_data()
  {

  }

}



 ?>