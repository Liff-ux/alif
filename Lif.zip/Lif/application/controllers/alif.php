<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Alif extends CI_Controller {

    public function index() {
        $this->load->model('m_datadiri');
        $data['data_diri'] = $this->m_datadiri->get_data();

        $this->load->view('v_datadiri', $data);
    }

}
